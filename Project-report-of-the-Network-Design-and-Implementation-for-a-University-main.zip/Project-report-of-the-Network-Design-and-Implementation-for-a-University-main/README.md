# Project report of the Network Design and Implementation for a University
With the increasing demand for information and communication that is being a daily necessity for day-to-day transactions, the delivery of both aspects is of utmost importance within the environment of education.
Therein, in such situations providing fast and always available resources that are accessible to the student body and staff is one of the most important factors in an education facility providing innovative ways to learn and vocationally develop.
![alt text](https://github.com/zudeera/Project-report-of-the-Network-Design-and-Implementation-for-a-University/blob/main/Physical%20Topology.jpg)
![alt text](https://github.com/zudeera/Project-report-of-the-Network-Design-and-Implementation-for-a-University/blob/main/Cloud%20Network%20Topology.jpg)
![alt text](https://github.com/zudeera/Project-report-of-the-Network-Design-and-Implementation-for-a-University/blob/main/Internal%20Server%20Topology%20(Logical).jpg)
![alt text](https://github.com/zudeera/Project-report-of-the-Network-Design-and-Implementation-for-a-University/blob/main/Demilitarized%20Zone%20Server%20Topology%20(Logical).jpg)
